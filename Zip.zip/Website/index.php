<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ayurvedic Treatment</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<script type="text/javascript">
    function googleTranslateElementInit() {
        new google.translate.TranslateElement({
            pageLanguage: 'en', // Set the default language to English
            layout: google.translate.TranslateElement.InlineLayout.SIMPLE
        }, 'google_translate_element');
    }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>


</head>
<body>

    <div id="google_translate_element"></div>
    
    <div class="main">
        <div class="navbar">
           <img src="logo.jpg="logo" alt="">
            <ul>
                <li><a href="#home">HOME</a></li>
                <li><a href="product.php">PRODUCT</a></li>
                <li><a href="formulation.php">FORMULATION</a></li>
                
                <!-- Dropdown Menu for Location -->
                <li class="dropdown">
                    <a href="javascript:void(0)" class="dropbtn">EXPLORE</a>
                    <div class="dropdown-content">
                        <a href="contact.php">CONTACT US</a>
                        <a href="about.php">ABOUT US</a>
                        <a href="map.php">LOCATION</a>
                        
                        
                    </div>
                </li>
                
                <li><a href="login.php">LOGIN</a></li>
                <li><a href="form.php">REGISTER</a></li>
            </ul>
        </div>

        <div class="content">
            <h1>AYURVEDIC TREATMENT</h1>
            <p>Ayurveda or Ayurvedic medicine is a system of traditional medicine native to India. Treatment options are varied and can include yoga, acupuncture, herbal medicine, massage therapy, and dietary changes.</p>
            <a href="form.php" class="btn">Get Started</a>
        </div>

        <div class="slideshow-container">
            <div class="mySlides fade">
                <div class="numbertext">1 / 6</div>
                <img src="b14.jpg" style="width:60%">
            </div>
          
            <div class="mySlides fade">
                <div class="numbertext">2 / 6</div>
                <img src="b10.jpg" style="width:60%">
            </div>

            <div class="mySlides fade">
                <div class="numbertext">3 / 6</div>
                <img src="b2.jpg" style="width:60%">
            </div>
          
            <div class="mySlides fade">
                <div class="numbertext">4 / 6</div>
                <img src="b12.jpg" style="width:60%">
            </div>

            <div class="mySlides fade">
                <div class="numbertext">5 / 6</div>
                <img src="b11.jpg" style="width:60%">
            </div>

            <div class="mySlides fade">
                <div class="numbertext">6 / 6</div>
                <img src="b13.jpg" style="width:60%">
            </div>

            <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
            <a class="next" onclick="plusSlides(1)">&#10095;</a>
        </div>
        <br>

        <div style="text-align:center">
            <span class="dot" onclick="currentSlide(1)"></span>
            <span class="dot" onclick="currentSlide(2)"></span>
            <span class="dot" onclick="currentSlide(3)"></span>
            <span class="dot" onclick="currentSlide(4)"></span>
            <span class="dot" onclick="currentSlide(5)"></span>
            <span class="dot" onclick="currentSlide(6)"></span>
        </div>

        <div class="info-section">
            <div class="info-card">
                <img src="image.jpg" alt="Herbal Treatment" class="info-img">
                <p>Some Ayurvedic medicines have herbs, metals, minerals, and other materials that may be harmful if not used safely.</p>
            </div>
            <div class="info-card">
                <img src="image1.jpg" alt="Natural Medicine" class="info-img">
                <p>The Ayurvedic drugs are derived from plant-based sources, with formulations involving animal, mineral, and plant origins.</p>
            </div>
        </div>

        <div class="gallery" id="home">
            <h1>Treatments</h1>
            <div class="gallery_image_box">
                <div class="gallery_image">
                    <img src="1.jpg" alt="">
                    <h3>Meditation</h3>
                    <p>Meditation practice helps free the mind of old, unhelpful thoughts, expanding awareness.</p>
                </div>

                <div class="gallery_image">
                    <img src="10.jpg" alt="">
                    <h3>Panchakarma</h3>
                    <p>Panchakarma therapy helps rekindle digestive enzymes, balancing the body's natural processes.</p>
                </div>

                <div class="gallery_image">
                    <img src="3.jpg" alt="">
                    <h3>Acupuncture</h3>
                    <p>Aligns with the body's natural energy channels to restore balance and provide relief.</p>
                </div>

                <div class="gallery_image">
                    <img src="m1.jpg" alt="">
                    <h3>Massage</h3>
                    <p>Ayurvedic massages stimulate the lymphatic system, aiding in toxin removal from the body.</p>
                </div>

                <div class="gallery_image">
                    <img src="11.jpg" alt="">
                    <h3>Nasya</h3>
                    <p>Nasya is an excellent remedy for headaches, clearing sinuses and enhancing breathing.</p>
                </div>

                <div class="gallery_image">
                    <img src="6.jpg" alt="">
                    <h3>Yoga</h3>
                    <p>Yoga dissolves physical stress and calms the mind, essential for a balanced body and soul.</p>
                </div>
            </div>
        </div>

        <footer>
            <div class="footer-content">
                <h3>Contact Us</h3>
                <p>Email: info@ayurveda.com | Phone: +91 12345 67890</p>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-linkedin"></i></a>
                </div>
            </div>
        </footer>
    </div>

    <script src="script4.js"></script>
</body>
</html>
