<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ayurvedic Products E-Commerce</title>
    <link rel="stylesheet" href="style1.css">  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<script type="text/javascript">
    function googleTranslateElementInit() {
        new google.translate.TranslateElement({
            pageLanguage: 'en', // Set the default language to English
            layout: google.translate.TranslateElement.InlineLayout.SIMPLE
        }, 'google_translate_element');
    }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>


</head>
<body>

    <div id="google_translate_element"></div>

    
    <header>
        <div class="navbar">
            <img src=".jpg" class="logo" alt="">
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="product.php">PRODUCT</a></li>
                <li><a href="formulation.php">FORMULATION</a></li>
                
                <!-- Dropdown Menu for Location -->
                <li class="dropdown">
                    <a href="javascript:void(0)" class="dropbtn">EXPLORE</a>
                    <div class="dropdown-content">
                        <a href="contact.php">CONTACT US</a>
                        <a href="about.php">ABOUT US</a>
                        <a href="map.php">LOCATION</a>
                        
                        
                    </div>
                </li>
                
                <li><a href="login.php">LOGIN</a></li>
                <li><a href="form.php">REGISTER</a></li>
            </ul>
        </div>
    </header>

    <div class="main-content">
        <section id="products" class="product-section">
            <div class="container">
                <h1>Our Ayurvedic Products</h1>
                <div class="search-container">
                    <input type="text" id="search-bar" placeholder="Search products..." onkeyup="filterProducts()">
                    <button class="search-btn"><i class="fas fa-search"></i></button>
                </div>
                <div class="product-grid" id="product-grid">
                    <!-- Product Cards -->
                    <div class="product-card">
                        <img src="p24.jpg" alt="Tulsi">
                        <h3>Rose, Cinnamon & Orange Soap</h3>
                        <p>A fragrant body soapreplenish and detoxify the skin.
                        </p>
                        <button class="btn" onclick="addToCart('Rose, Cinnamon & Orange Soap', 12.99)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Rose, Cinnamon & Orange Soap')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p25.jpg" alt="Tulsi">
                        <h3>Bringadi Hair Mask</h3>
                        <p>Ideal for dry and damaged hair. For weekly use.
                        </p>
                        <button class="btn" onclick="addToCart('Bringadi Hair Mask', 25.99)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Bringadi Hair Mask')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p3.jpg" alt="Tulsi">
                        <h3>Pure Neroli Water</h3>
                        <p>Its citrus scent also lifts the mood and relieves tension.
                        </p>
                        <button class="btn" onclick="addToCart('Pure Neroli Water', 10.00)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Pure Neroli Water')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p4.jpg" alt="Tulsi">
                        <h3>Anti Acne Spot Corrector</h3>
                        <p>Ayurveda-derived spot formula that targets blemishes.
                        </p>
                        <button class="btn" onclick="addToCart('Anti Acne Spot Corrector', 18.00)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Anti Acne Spot Corrector')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p5.jpg" alt="Ashwagandha">
                        <h3>Eladi Hydrating Face Cream</h3>
                        <p>This rich nourishing face cream helps improve texture & repairs skin barrier.
                        </p>
                        <button class="btn" onclick="addToCart('Eladi Hydrating Face Cream', 15.99)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Eladi Hydrating Face Cream')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p6.jpg" alt="Ashwagandha">
                        <h3>Kumkumadi Facial Oil</h3>
                        <p>An ayurvedic face oil​ powered by Saffron for youthful & radiant skin.</p>
                        <button class="btn" onclick="addToCart('Kumkumadi Facial Oil', 17.99)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Kumkumadi Facial Oil')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p7.jpg" alt="Ashwagandha">
                        <h3>Rose Jasmine Face Cleanser</h3>
                        <p>Herbal face cleanser with a rich blend of Ayurvedic ingredients to effectively cleanse.</p>
                        <button class="btn" onclick="addToCart('Rose Jasmine Face Cleanser', 11.99)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Rose Jasmine Face Cleanser')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p8.jpg" alt="Ashwagandha">
                        <h3>Turmeric & Myrrh Soap</h3>
                        <p>Turmeric that lightens complexion,reduces pigmentation,and protects the skin.
                        </p>
                        <button class="btn" onclick="addToCart('Turmeric & Myrrh Soap', 13.00)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Turmeric & Myrrh Soap')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p9.jpg" alt="Ashwagandha">
                        <h3>Vanilla Lip Care</h3>
                        <p>A Vanilla lip balm that leaves the lips replenished, soft and hydrated.
                        </p>
                        <button class="btn" onclick="addToCart('Vanilla Lip Care', 21.99)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Vanilla Lip Care')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p11.jpg" alt="Ashwagandha">
                        <h3>Eladi Hydrating Light Cream</h3>
                        <p>A lightweight, non-greasy formulation for youthful, smooth & supple skin.</p>
                        <button class="btn" onclick="addToCart('Eladi Hydrating Light Cream', 24.00)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Eladi Hydrating Light Cream')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p10.jpg" alt="Ashwagandha">
                        <h3>Eye Contour Renewal</h3>
                        <p>Ayurveda-derived eye serum that revives, hydrates eye area.</p>
                        <button class="btn" onclick="addToCart('Eye Contour Renewal', 9.99)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Eye Contour Renewal')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p12.jpg" alt="Ashwagandha">
                        <h3>Bringadi Hair Conditioner</h3>
                        <p>Powered with Kama Ayurveda’s Bringadi Intensive Hair Oil actives.</p>
                        <button class="btn" onclick="addToCart('Bringadi Hair Conditioner', 16.00)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Bringadi Hair Conditioner')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p13.jpg" alt="Ashwagandha">
                        <h3>Himalayan Deodar Hair Cleanser</h3>
                        <p>A purifying and scalp toning natural hair cleanser for weak and thinning hair.</p>
                        <button class="btn" onclick="addToCart('Himalayan Deodar Hair Cleanser', 20.99)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Himalayan Deodar Hair Cleanser')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p14.jpg" alt="Ashwagandha">
                        <h3>Rose & Jasmine Hair Cleanser</h3>
                        <p>A restoring and balancing natural cleanser that improves hair strength .</p>
                        <button class="btn" onclick="addToCart('Rose & Jasmine Hair Cleanser', 22.99)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Rose & Jasmine Hair Cleanser')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p15.jpg" alt="Ashwagandha">
                        <h3>Organic Hair Color Kit</h3>
                        <p>That dyes your hair black naturally, leaving them healthier and shinier.</p>
                        <button class="btn" onclick="addToCart('Organic Hair Color Kit', 32.99)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Organic Hair Color Kit')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p16.jpg" alt="Ashwagandha">
                        <h3>Anti Acne Cleansing Foam</h3>
                        <p>A lightweight aromatic cleansing foam for deep purification.</p>
                        <button class="btn" onclick="addToCart('Anti Acne Cleansing Foam', 35.00)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Anti Acne Cleansing Foam')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p20.jpg" alt="Ashwagandha">
                        <h3>Kokum Almond Cleansing Shower Oil</h3>
                        <p>Luxurious Body Cleanser to recharge & rejuvenate.</p>
                        <button class="btn" onclick="addToCart('Kokum Almond Cleansing Shower Oil', 14.00)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Kokum Almond Cleansing Shower Oil')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p17.jpg" alt="Ashwagandha">
                        <h3>Kokum And Almond Body Butter</h3>
                        <p>That gives intensive hydration instantly and keeps skin soft and protected.</p>
                        <button class="btn" onclick="addToCart('Kokum And Almond Body Butter', 29.99)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Kokum And Almond Body Butterr')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p22.jpg" alt="Ashwagandha">
                        <h3>Baby Massage Oil</h3>
                        <p>The ultimate top-to-toe baby massage oil that soothes, nourishes, protects.</p>
                        <button class="btn" onclick="addToCart('Baby Massage Oil', 33.00)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Baby Massage Oil')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p23.jpg" alt="Ashwagandha">
                        <h3>Shea Lotus Body Butter</h3>
                        <p>Body Butter that provides deep-skin nourishment, alleviates dryness .</p>
                        <button class="btn" onclick="addToCart('Shea Lotus Body Butter', 39.99)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Shea Lotus Body Butter')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p18.jpg" alt="Ashwagandha">
                        <h3>Foot Cream</h3>
                        <p>Foot cream enriched with natural ingredients to nourish, soothe and refresh tired feet.</p>
                        <button class="btn" onclick="addToCart('Foot Cream', 37.00)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Foot Cream')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p19.jpg" alt="Ashwagandha">
                        <h3>Hand Cream</h3>
                        <p>Hand cream that leaves hands feeling soft, supple, and moisturized all day long.</p>
                        <button class="btn" onclick="addToCart('Hand Cream', 23.00)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Hand Cream')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p21.jpg" alt="Ashwagandha">
                        <h3>Natural Khus Soap</h3>
                        <p>Khus soap that softens, refreshes, and revives tired mind and body.</p>
                        <button class="btn" onclick="addToCart('Natural Khus Soap', 30.99)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Natural Khus Soap')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p26.jpg" alt="Ashwagandha">
                        <h3>Hair & Scalp Oil</h3>
                        <p>Get shinier, healthier, and luxurious hair.</p>
                        <button class="btn" onclick="addToCart('Hair & Scalp Oil', 10.99)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Hair & Scalp Oil')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p27.jpg" alt="Ashwagandha">
                        <h3>Muscle Release Oil</h3>
                        <p>Best Sellers Alleviate muscle & joint pain with  Frankincense.
                        </p>
                        <button class="btn" onclick="addToCart('Muscle Release Oil', 14.99)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Muscle Release Oil')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p28.jpg" alt="Ashwagandha">
                        <h3>Kansa Hair Comb</h3>
                        <p>Made with 100% pure Kansa metal.
                        </p>
                        <button class="btn" onclick="addToCart('Kansa Hair Comb', 19.99)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Kansa Hair Comb')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p30.jpg" alt="Ashwagandha">
                        <h3>Timeless Moisturizer</h3>
                        <p>Elixir for an eternal glowing skin enriched with Kumkumadi Oil. </p>
                        <button class="btn" onclick="addToCart('Timeless Moisturizer',16.00 )">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Timeless Moisturizer')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p29.jpg" alt="Ashwagandha">
                        <h3>Kansa Massage & Marma Wand</h3>
                        <p>Ayurveda's best kept secret for a radiant you.
                        </p>
                        <button class="btn" onclick="addToCart('Kansa Massage & Marma Wand', 34.00)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Kansa Massage & Marma Wand')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p31.jpg" alt="Ashwagandha">
                        <h3>Hydrating Body Silk</h3>
                        <p>Deeply hydrated, supple skin with Sandalwood.</p>
                        <button class="btn" onclick="addToCart('Hydrating Body Silk ', 16.99)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Hydrating Body Silk')">Add to Wishlist</button>
                    </div>
                    <div class="product-card">
                        <img src="p32.jpg" alt="Ashwagandha">
                        <h3>Gheesutrā Mango Lip Butter</h3>
                        <p>Nourish and Protect with Ghee and Mango</p>
                        <button class="btn" onclick="addToCart('Gheesutrā Mango Lip Butter', 25.00)">Add to Cart</button>
                        <button class="btn" onclick="addToWishlist('Gheesutrā Mango Lip Butter')">Add to Wishlist</button>
                    </div>
                </div>
            </div>
        </section>

        <aside class="cart">
            <h2>Shopping Cart</h2>
            <ul id="cart-items"></ul>
            <div id="total-amount">Total: $0</div>
        </aside>
    </div>

    <footer id="contact">
        <div class="container">
            <p>Contact us: info@ayurvedichealing.com | +1 234 567 890</p>
            <p>&copy; 2024 Ayurvedic Healing. All rights reserved.</p>
        </div>
    </footer>

    <script src="script.js"></script>
</body>
</html>
