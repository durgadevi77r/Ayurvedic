<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Ayurvedic Healing</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<script type="text/javascript">
    function googleTranslateElementInit() {
        new google.translate.TranslateElement({
            pageLanguage: 'en', // Set the default language to English
            layout: google.translate.TranslateElement.InlineLayout.SIMPLE
        }, 'google_translate_element');
    }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>


    <style>
    
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            line-height: 1.6;
        }

        .navbar {
    width: 100%;
    padding: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.logo {
    width: 150px;
}

.navbar ul {
    display: flex;
}

.navbar ul li {
    list-style: none;
    margin: 0 15px;
}

.navbar ul li a {
    color: #0e0e0e;
    text-transform: uppercase;
    text-decoration: none;
    padding: 5px 10px;
    transition: background 0.3s;
}

.navbar ul li a:hover {
    background: #6cf9eb;
    border-radius: 5px;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown .dropbtn {
    background-color: transparent;
    color: rgb(16, 16, 16);
    border: none;
    cursor: pointer;
    text-transform: uppercase;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #989c9c;
    min-width: 160px;
    box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    transition: background-color 0.3s ease;
}

.dropdown-content a:hover {
    background-color: #ddd;
}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: #6cf9eb;
    border-radius: 5px;
}


        header {
            background: #f4f4f9;
            padding: 60px 0;
            text-align: center;
            box-shadow: 0 4px 8px rgba(189, 92, 92, 0.1);
        }

        header h1 {
            font-size: 3rem;
            margin-bottom: 10px;
            color: #2c3e50;
        }

        header p {
            font-size: 1.2rem;
            color: #7f8c8d;
        }

        .about-content {
            padding: 50px 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .about-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }

        .about-item {
            background-color: #e9e5f0;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .about-item:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .about-item h2 {
            font-size: 2rem;
            margin-bottom: 20px;
            color: #16a085;
        }

        .about-item p {
            font-size: 1.1rem;
            color: #555;
            margin-bottom: 15px;
            line-height: 1.7;
        }

        .about-item i {
            font-size: 3rem;
            color: #16a085;
            margin-bottom: 15px;
        }

        .mission-section {
            background-color: #eaf2e3;
            padding: 50px 20px;
            text-align: center;
        }

        .mission-section h2 {
            font-size: 2.5rem;
            margin-bottom: 20px;
            color: #27ae60;
        }

        .mission-section p {
            font-size: 1.2rem;
            max-width: 800px;
            margin: 0 auto;
            color: #555;
        }

        footer {
            background-color: #2c3e50;
            color: #c05e5e;
            padding: 20px;
            text-align: center;
        }

        footer p {
            margin: 0;
            font-size: 1rem;
        }

        footer a {
            color: #1abc9c;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .about-item h2 {
                font-size: 1.5rem;
            }

            .about-item p {
                font-size: 1rem;
            }

            .mission-section h2 {
                font-size: 2rem;
            }

            .mission-section p {
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>

    <div id="google_translate_element"></div>

    <div class="navbar">
        <img src=".jpg" class="logo" alt="">
        <ul>
            <li><a href="index.php">HOME</a></li>
            <li><a href="product.php">PRODUCT</a></li>
            <li><a href="formulation.php">FORMULATION</a></li>
            
            <!-- Dropdown Menu for Location -->
            <li class="dropdown">
                <a href="javascript:void(0)" class="dropbtn">EXPLORE</a>
                <div class="dropdown-content">
                    <a href="contact.php">CONTACT US</a>
                    <a href="about.php">ABOUT US</a>
                    <a href="map.php">LOCATION</a>
                    
                    
                </div>
            </li>
            
            <li><a href="login.php">LOGIN</a></li>
            <li><a href="form.php">REGISTER</a></li>
        </ul>
    </div>

    <!-- Header -->
    <header>
        <h1>Discover Ayurvedic Healing</h1>
        <p>Embrace the power of nature and holistic well-being</p>
    </header>

    <!-- Main About Content -->
    <div class="about-content">
        <div class="about-grid">
            <div class="about-item">
                <i class="fas fa-leaf"></i>
                <h2>Natural Wellness</h2>
                <p>At Ayurvedic Healing, we believe in the power of nature to restore balance and promote holistic well-being. Our products are rooted in ancient Ayurvedic traditions and crafted to help you achieve optimal health naturally.</p>
            </div>

            <div class="about-item">
                <i class="fas fa-hand-holding-heart"></i>
                <h2>100% Pure Ingredients</h2>
                <p>We are committed to using only the purest ingredients in our products. Each formulation is crafted with care, ensuring that you receive the full benefits of nature's most powerful remedies.</p>
            </div>

            <div class="about-item">
                <i class="fas fa-heartbeat"></i>
                <h2>Holistic Healing</h2>
                <p>Our approach to health is rooted in the holistic principles of Ayurveda, addressing the mind, body, and spirit. We offer remedies for everything from stress and anxiety to digestive health and immunity support.</p>
            </div>

            <div class="about-item">
                <i class="fas fa-spa"></i>
                <h2>Sustainable Practices</h2>
                <p>We care deeply about the planet and source our ingredients ethically. From eco-friendly packaging to sustainable farming practices, we are dedicated to minimizing our environmental impact.</p>
            </div>

            <div class="about-item">
                <i class="fas fa-users"></i>
                <h2>Trusted by Communities</h2>
                <p>For years, Ayurvedic Healing has been trusted by communities around the world to provide effective and reliable health solutions. We are honored to continue serving our customers with integrity and dedication.</p>
            </div>

            <div class="about-item">
                <i class="fas fa-globe"></i>
                <h2>Global Reach</h2>
                <p>Our products are available worldwide, helping individuals from diverse backgrounds discover the benefits of Ayurveda. We aim to make natural wellness accessible to everyone, no matter where you are.</p>
            </div>
        </div>
    </div>

    <!-- Mission Section -->
    <section class="mission-section">
        <h2>Our Mission</h2>
        <p>To bridge the gap between ancient Ayurvedic wisdom and modern wellness needs. We strive to create natural, sustainable, and effective health solutions that empower individuals to take control of their well-being.</p>
    </section>

    <!-- Footer -->
    <footer>
        <p>Contact us: <a href="mailto:info@ayurvedichealing.com">info@ayurvedichealing.com</a> | +1 234 567 890</p>
        <p>&copy; 2024 Ayurvedic Healing. All rights reserved.</p>
    </footer>

</body>
</html>

