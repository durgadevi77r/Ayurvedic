<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Registration Form</title>
    <link rel="stylesheet" href="styles.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<script type="text/javascript">
    function googleTranslateElementInit() {
        new google.translate.TranslateElement({
            pageLanguage: 'en', // Set the default language to English
            layout: google.translate.TranslateElement.InlineLayout.SIMPLE
        }, 'google_translate_element');
    }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>



    
</head>
<body>


    <div id="google_translate_element"></div>  

    
    <div class="navbar">
        <img src=".jpg" class="logo" alt="">
        <ul>
            <li><a href="index.php">HOME</a></li>
            <li><a href="product.php">PRODUCT</a></li>
            <li><a href="formulation.php">FORMULATION</a></li>
            
            <!-- Dropdown Menu for Location -->
            <li class="dropdown">
                <a href="javascript:void(0)" class="dropbtn">EXPLORE</a>
                <div class="dropdown-content">
                    <a href="contact.php">CONTACT US</a>
                    <a href="about.php">ABOUT US</a>
                    <a href="map.php">LOCATION</a>
                    
                    
                </div>
            </li>
            
            <li><a href="login.php">LOGIN</a></li>
            <li><a href="form.php">REGISTER</a></li>
        </ul>
    </div>
    <h2>Patient Registration Form</h2>
    <form action="/submit_form" method="post">
        <div class="container">
            <label for="fname">First Name</label>
            <input type="text" id="fname" name="firstname" required>

            <label for="lname">Last Name</label>
            <input type="text" id="lname" name="lastname" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>

            <label for="phone">Phone Number</label>
            <input type="tel" id="phone" name="phone" required>

            <label for="dob">Date of Birth</label>
            <input type="date" id="dob" name="dob" required>

            <label for="gender">Gender</label>
            <select id="gender" name="gender" required>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
            </select>

            <label for="address">Address</label>
            <textarea id="address" name="address" rows="4" required></textarea>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>


            <button type="submit">Register</button>
        </div>
    </form>
</body>
</html>
