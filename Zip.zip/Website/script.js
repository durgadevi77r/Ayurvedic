let cart = [];
let wishlist = [];

function addToCart(product, price) {
    const existingProduct = cart.find(item => item.product === product);
    if (existingProduct) {
        existingProduct.quantity++;
    } else {
        cart.push({ product, price, quantity: 1 });
    }
    updateCart();
}

function addToWishlist(product) {
    if (!wishlist.includes(product)) {
        wishlist.push(product);
        alert(`${product} added to your wishlist!`);
    } else {
        alert(`${product} is already in your wishlist!`);
    }
}

function increaseQuantity(product) {
    const existingProduct = cart.find(item => item.product === product);
    if (existingProduct) {
        existingProduct.quantity++;
    }
    updateCart();
}

function decreaseQuantity(product) {
    const existingProduct = cart.find(item => item.product === product);
    if (existingProduct) {
        if (existingProduct.quantity > 1) {
            existingProduct.quantity--;
        } else {
            cart = cart.filter(item => item.product !== product); // Remove item if quantity is 0
        }
    }
    updateCart();
}

function updateCart() {
    const cartItems = document.getElementById('cart-items');
    const totalAmount = document.getElementById('total-amount');
    
    cartItems.innerHTML = '';
    let total = 0;

    cart.forEach(item => {
        total += item.price * item.quantity;
        const listItem = document.createElement('li');
        listItem.innerHTML = `
            <div class="cart-item">
                <span>${item.product} - $${item.price} x ${item.quantity}</span>
                <div class="quantity-controls">
                    <button class="btn" onclick="decreaseQuantity('${item.product}')">-</button>
                    <span id="quantity-${item.product}">${item.quantity}</span>
                    <button class="btn" onclick="increaseQuantity('${item.product}')">+</button>
                </div>
            </div>`;
        cartItems.appendChild(listItem);
    });

    totalAmount.innerHTML = `Total: $${total}`;
}

function filterProducts() {
    const input = document.getElementById('search-bar').value.toLowerCase();
    const productCards = document.querySelectorAll('.product-card');

    productCards.forEach(card => {
        const productName = card.querySelector('h3').innerText.toLowerCase();
        card.style.display = productName.includes(input) ? 'block' : 'none';
    });
}

