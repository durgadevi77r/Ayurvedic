// Show Forgot Password box
function showForgotPassword() {
    document.getElementById('forgot-password-box').classList.toggle('hidden');
}

// Simulate sending a reset link
function sendResetLink() {
    var email = document.getElementById('reset-email').value;
    if (email) {
        alert("Password reset link has been sent to " + email);
    } else {
        alert("Please enter a valid email address.");
    }
}

