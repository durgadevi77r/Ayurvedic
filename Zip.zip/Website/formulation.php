<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ayurvedic Medicine Finder</title>
    <link rel="stylesheet" href="style2.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<script type="text/javascript">
    function googleTranslateElementInit() {
        new google.translate.TranslateElement({
            pageLanguage: 'en', // Set the default language to English
            layout: google.translate.TranslateElement.InlineLayout.SIMPLE
        }, 'google_translate_element');
    }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
 
</head>
<body>

    <div id="google_translate_element"></div>  

    
    <div class="navbar">
        <img src=".jpg" class="logo" alt="">
        <ul>
            <li><a href="index.php">HOME</a></li>
            <li><a href="product.php">PRODUCT</a></li>
            <li><a href="formulation.php">FORMULATION</a></li>
            
            <!-- Dropdown Menu for Location -->
            <li class="dropdown">
                <a href="javascript:void(0)" class="dropbtn">EXPLORE</a>
                <div class="dropdown-content">
                    <a href="contact.php">CONTACT US</a>
                    <a href="about.php">ABOUT US</a>
                    <a href="map.php">LOCATION</a>
                    
                </div>
            </li>
            
            <li><a href="login.php">LOGIN</a></li>
            <li><a href="form.php">REGISTER</a></li>
        </ul>
    </div>
    <div class="container">
        <h1>Ayurvedic Medicine Finder</h1>
        <p>Enter a disease name to get Ayurvedic medicine suggestions and preparation steps.</p>
        
        <label for="disease">Disease Name:</label>
        <input type="text" id="disease" placeholder="E.g., Fever, Cold, Diabetes">
        
        <button onclick="getSuggestions()">Get Suggestions</button>
        <button id="voiceBtn">🎤 Speak</button>
        <div id="result"></div>
    </div>

    <script src="script2.js"></script>
</body>
</html>






